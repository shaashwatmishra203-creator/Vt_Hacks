# GobbleGood — updated code

Includes the Next.js frontend and Python FastAPI backend. Features: nutrition filters, live VT menus, dining hall status, walking-directions links, GobbleGood logo, jumping-bird loader, and a built-in meal chatbot.

## 1. Start backend
Open a terminal inside the backend folder and run each line:

```sh
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 127.0.0.1 --port 8000
```

## 2. Start frontend
Open a second terminal inside the frontend folder:

```sh
npm install
npm run dev
```

Keep both terminals running. Open http://localhost:3000.
If an older copy is running, stop it with Control+C before starting this copy.

## Try the chatbot
Click Ask GobbleGood and send:
Dinner under 650 calories with at least 30g protein at West End
Review the filters and click Search live menus. Follow up with another limit or say reset filters.

The chatbot is a rule-based meal assistant, not generative AI or HokieAI. It requires no API key. Use the survey for allergy changes. Walking durations are unavailable; result cards link to Google Maps. Menu data and scheduled opening status are separate.

## Validation
Frontend lint and production build passed. Backend: 17 tests passed.
To run backend tests, install requirements-dev.txt and run python -m unittest test_chat test_integration.

Dependencies, generated build files, Git history, and secret environment files are omitted. Install dependencies using the steps above. For hosted deployment, configure NEXT_PUBLIC_API_BASE_URL and FRONTEND_ORIGINS; the defaults are for local development.
