import unittest
from fastapi.testclient import TestClient
from main import app


class ChatTests(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def ask(self, message, preferences=None):
        response = self.client.post('/chat', json={'message': message, 'preferences': preferences or {}})
        self.assertEqual(response.status_code, 200)
        return response.json()

    def test_meal_request_and_followup(self):
        first = self.ask('dinner under 650 calories with at least 30g protein at West End')
        self.assertTrue(first['can_search'])
        self.assertEqual(first['preferences']['dining_location'], '16')
        self.assertEqual(first['preferences']['max_calories'], 650)
        self.assertEqual(first['preferences']['min_protein_g'], 30)
        second = self.ask('at least 40g protein', first['preferences'])
        self.assertEqual(second['preferences']['max_calories'], 650)
        self.assertEqual(second['preferences']['min_protein_g'], 40)
        self.assertEqual(second['preferences']['meal_period'], 'dinner')

    def test_allergies_are_preserved(self):
        result = self.ask('lunch under 600 calories', {'allergies': ['milk']})
        self.assertEqual(result['preferences']['allergies'], ['milk'])
        result = self.ask('dinner without peanuts', {'allergies': ['milk']})
        self.assertFalse(result['can_search'])
        self.assertEqual(result['preferences']['allergies'], ['milk'])
        self.assertIsNone(result['preferences']['meal_period'])

    def test_negation_and_conflicting_values_are_not_guessed(self):
        for text in ['not vegan', "don't use under 600 calories", 'under 500 calories or under 800 calories']:
            result = self.ask(text, {'max_calories': 650})
            self.assertFalse(result['can_search'])
            self.assertEqual(result['preferences']['max_calories'], 650)

    def test_nearby_hall_not_destination(self):
        result = self.ask('lunch near Turner', {'dining_location': '16'})
        self.assertEqual(result['preferences']['dining_location'], '16')

    def test_reset_and_unknown_request(self):
        result = self.ask('reset filters', {'allergies': ['milk'], 'max_calories': 600})
        self.assertEqual(result['preferences']['allergies'], [])
        self.assertIsNone(result['preferences']['max_calories'])
        result = self.ask('write my essay')
        self.assertFalse(result['can_search'])
        self.assertEqual(result['mode'], 'built_in')

    def test_limits(self):
        for text in ['', 'a' * 1001]:
            self.assertEqual(self.client.post('/chat', json={'message': text}).status_code, 422)


if __name__ == '__main__':
    unittest.main()
