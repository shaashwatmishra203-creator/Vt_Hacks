import os
from datetime import datetime
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import requests
from models.recommendation import RecommendationRequest, RecommendationResponse
from services.vt_dining import VTDiningConnector, TZ
from services.recommendation import RecommendationService
from services.chat import ChatRequest, chat_reply

app = FastAPI(title="GobbleGood API", version="0.5.0")
app.add_middleware(CORSMiddleware,
    allow_origins=[value.strip() for value in os.getenv("FRONTEND_ORIGINS",
        "http://localhost:3000,http://127.0.0.1:3000,http://localhost:3001").split(",")],
    allow_methods=["GET", "POST"], allow_headers=["Content-Type"])

@app.get("/health")
def health():
    return {"status": "healthy", "version": "0.5.0"}

@app.post("/chat")
def chat(request: ChatRequest):
    return chat_reply(request)

@app.get("/dining-locations")
def locations():
    try:
        return {"locations": VTDiningConnector().location_catalog(),
                "checked_at": datetime.now(TZ).isoformat(),
                "coverage_note": "Locations and scheduled hours come from VT. Empty menus do not mean closed."}
    except (requests.RequestException, ValueError, TypeError, KeyError) as exc:
        raise HTTPException(503, "VT's dining directory could not be loaded. Please retry.") from exc

@app.post("/recommend", response_model=RecommendationResponse)
def recommend(request: RecommendationRequest):
    if request.priority == "convenience":
        raise HTTPException(422, "Walking-time ranking is not available. Walking directions are linked on result cards.")
    now = datetime.now(TZ)
    connector = VTDiningConnector()
    try:
        catalog = connector.location_catalog(now)
        foods, selected, warnings = connector.search_foods(request.dining_location, catalog, now, request.meal_period)
    except requests.RequestException as exc:
        raise HTTPException(503, "VT Dining is temporarily unreachable. Please retry.") from exc
    except (ValueError, TypeError, KeyError) as exc:
        raise HTTPException(422, str(exc)) from exc
    if all(loc["menu_status"] == "unavailable" for loc in selected):
        raise HTTPException(503, "Menus for the selected locations could not be loaded. Please retry.")
    result = RecommendationService().recommend(request, foods)
    if not foods:
        result.status = "no_menu_available"
        warnings.append("No menu items are published for this selection and meal period. Try another meal period or dining location.")
    result.location_statuses = selected
    result.warnings = warnings
    return result
