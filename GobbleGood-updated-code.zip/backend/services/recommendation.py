"""Deterministic filtering. Unknown nutrition never satisfies a numeric limit."""
from datetime import datetime, timezone
from math import isfinite
from models.recommendation import RecommendationRequest, RecommendationResponse, RecommendationItem, NutritionResponse, Adjustment

FIELDS = {"max_calories": "calories", "min_protein_g": "protein", "max_carbs_g": "carbs", "max_fat_g": "fat", "max_sugar_g": "sugar"}
ALIASES = {"dairy": "milk", "soy": "soybeans", "egg": "eggs", "peanut": "peanuts", "tree nut": "tree nuts"}

def number(value):
    try:
        result = float(value)
        return result if isfinite(result) and result >= 0 else None
    except (ValueError, TypeError):
        return None

def allergens(value):
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    return [v.strip() for v in str(value or "").split(",") if v.strip()]

class RecommendationService:
    def _matches(self, request, food):
        for field, key in FIELDS.items():
            limit = getattr(request, field)
            if limit is None:
                continue
            value = number(food.get(key))
            if value is None:
                return False
            if (field.startswith("min_") and value < limit) or (field.startswith("max_") and value > limit):
                return False
        meal = str(food.get("meal", "")).lower().strip()
        if request.meal_period and request.meal_period.replace("_", " ") != meal:
            return False
        tags = {str(tag).lower() for tag in food.get("dietary_tags", [])}
        if "vegan" in tags:
            tags.add("vegetarian")
        if any(tag.lower() not in tags for tag in request.dietary_restrictions):
            return False
        listed = [a.lower() for a in allergens(food.get("allergens"))]
        for allergy in request.allergies:
            term = ALIASES.get(allergy.lower().strip(), allergy.lower().strip())
            # Empty source information is unknown, never a guarantee of allergy safety.
            if not listed or any(term in a for a in listed):
                return False
        return True

    def recommend(self, request: RecommendationRequest, foods):
        matches = [food for food in foods if self._matches(request, food)]
        matches.sort(key=lambda food: (
            -(number(food.get("protein")) if number(food.get("protein")) is not None else -1),
            number(food.get("calories")) if number(food.get("calories")) is not None else float("inf"),
            str(food.get("name", "")),
        ))
        items = []
        for food in matches[:20]:
            explanation = []
            for field, key in FIELDS.items():
                if getattr(request, field) is not None:
                    explanation.append(f"{number(food.get(key)):g} {key}, meets your requested limit")
            items.append(RecommendationItem(
                id=str(food["recipe_id"]), food_name=food["name"],
                location_name=food["location_name"], meal_period=food.get("meal"),
                location_id=food.get("location_id", ""),
                nutrition=NutritionResponse(calories=number(food.get("calories")),
                    protein_g=number(food.get("protein")), carbs_g=number(food.get("carbs")),
                    fat_g=number(food.get("fat")), sugar_g=number(food.get("sugar"))),
                dietary_tags=food.get("dietary_tags", []),
                allergens=allergens(food.get("allergens")),
                availability_status="listed_on_menu", menu_date=food["menu_date"],
                portion_size=str(food.get("portion_size") or ""),
                portion_unit=str(food.get("portion_unit") or ""),
                match_explanation=explanation,
            ))
        adjustments = []
        if not matches:
            for field, delta, label in [
                ("max_calories", 50, "+50 calories"),
                ("min_protein_g", -5, "Lower minimum protein by up to 5g"),
                ("max_carbs_g", 10, "+10g carbs"),
                ("max_fat_g", 5, "+5g fat"),
            ]:
                current = getattr(request, field)
                if current is None:
                    continue
                updated = max(0, current + delta)
                actual_delta = updated - current
                if not actual_delta:
                    continue
                modified = request.model_copy(update={field: updated})
                count = sum(self._matches(modified, food) for food in foods)
                if count:
                    adjustments.append(Adjustment(id=field, label=label,
                        change={field: actual_delta}, matching_option_count=count))
        return RecommendationResponse(status="matches_found" if items else "no_exact_matches",
            data_source="vt_dining", generated_at=datetime.now(timezone.utc),
            recommendations=items, adjustments=adjustments)
