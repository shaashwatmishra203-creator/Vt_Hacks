"""Bounded, deterministic meal assistant. Does not impersonate a generative AI."""
import re
from pydantic import BaseModel, Field, ConfigDict
from models.recommendation import RecommendationRequest


class ChatRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    message: str = Field(min_length=1, max_length=1000)
    preferences: RecommendationRequest = Field(default_factory=RecommendationRequest)


def chat_reply(request: ChatRequest) -> dict:
    text = request.message.lower().strip()
    current = request.preferences.model_dump()
    changes = {}
    notes = []
    # Negations and complex ranges must be clarified, never guessed.
    if re.search(r"\b(don't|do not|not|between|except)\b", text):
        return {"reply": "Please use a simple request, such as ‘dinner under 650 calories, at least 30g protein’. To remove every filter, say ‘reset filters’. Your existing filters are unchanged.", "preferences": current, "changed": [], "can_search": False, "mode": "built_in"}
    if text in {"reset", "reset filters", "clear filters", "start over"}:
        return {"reply": "All filters cleared. Tell me a meal period, calorie limit, protein minimum, or dining hall.", "preferences": RecommendationRequest().model_dump(), "changed": list(current), "can_search": True, "mode": "built_in"}
    patterns = {
        "max_calories": r"(?:under|below|maximum|max|at most|up to)\s+(\d+(?:\.\d+)?)\s*(?:calories|kcal|cal)\b",
        "min_protein_g": r"(?:at least|minimum|min|over)\s+(\d+(?:\.\d+)?)\s*(?:g|grams)?\s*(?:of\s+)?protein\b",
        "max_carbs_g": r"(?:under|below|maximum|max|at most|up to)\s+(\d+(?:\.\d+)?)\s*(?:g|grams)?\s*(?:of\s+)?carbs\b",
        "max_fat_g": r"(?:under|below|maximum|max|at most|up to)\s+(\d+(?:\.\d+)?)\s*(?:g|grams)?\s*(?:of\s+)?fat\b",
        "max_sugar_g": r"(?:under|below|maximum|max|at most|up to)\s+(\d+(?:\.\d+)?)\s*(?:g|grams)?\s*(?:of\s+)?sugar\b",
    }
    for field, pattern in patterns.items():
        values = re.findall(pattern, text)
        if len(values) > 1:
            return {"reply": "I found more than one limit for the same nutrient. Please send one limit at a time. No filters were changed.", "preferences": current, "changed": [], "can_search": False, "mode": "built_in"}
        if values:
            changes[field] = float(values[0])
    periods = [period for period in ["breakfast", "lunch", "dinner", "late night"] if re.search(r"\b" + period + r"\b", text)]
    if len(periods) == 1:
        changes["meal_period"] = periods[0].replace(" ", "_")
    elif len(periods) > 1:
        notes.append("Choose one meal period in the survey.")
    restrictions = [tag for tag in ["vegan", "vegetarian", "halal", "gluten-free"] if re.search(r"\b" + tag + r"\b", text)]
    if restrictions:
        changes["dietary_restrictions"] = sorted(set(current["dietary_restrictions"] + restrictions))
    halls = {"west end": "16", "turner": "14", "owens": "39", "hokie grill": "09", "d2": "15", "deet's": "72", "deets": "72", "dx": "71", "ducky": "01", "perry": "06", "squires": "18", "viva": "19", "xpress": "07"}
    found = {value for name, value in halls.items() if re.search(r"\b" + re.escape(name) + r"\b", text)}
    if len(found) == 1:
        if re.search(r"\b(near|closest|close to)\b", text):
            notes.append("Set your closest hall in the survey for directions; I did not change your dining destination.")
        else:
            changes["dining_location"] = found.pop()
    elif len(found) > 1:
        notes.append("Choose one dining destination in the survey.")
    if re.search(r"\b(allerg\w*|avoid|free|without|no)\b", text):
        notes.append("For allergies or ingredients to avoid, use the survey’s allergy field and confirm with dining staff. I have not added an allergy filter from this message.")
        # Never enable a search which could silently omit an allergy request.
        return {"reply": " ".join(notes) + " No filters were changed. Existing allergy filters are preserved.", "preferences": current, "changed": [], "can_search": False, "mode": "built_in"}
    if re.search(r"\b(walk\w*|distance|minutes)\b", text):
        notes.append("Walking times are unavailable. Results include Google Maps directions.")
    if re.search(r"\b(open|closed|hours)\b", text):
        notes.append("The Dining hall status section shows scheduled hours from VT. I cannot infer hours from a meal request.")
    if changes:
        updated = RecommendationRequest.model_validate({**current, **changes}).model_dump()
        reply = "I’ve prepared these filters. Review them below, then search today’s menu. Other filters stay as they were."
        if re.search(r"\b(healthy|high protein|low carb)\b", text):
            notes.append("For goals like ‘healthy’ or ‘high protein’, add a specific nutrition limit; I do not choose one for you.")
        return {"reply": " ".join([reply, *notes]), "preferences": updated, "changed": list(changes), "can_search": True, "mode": "built_in"}
    reply = "Try ‘dinner under 650 calories with at least 30g protein at West End’, ‘vegan lunch’, or ‘reset filters’. I can set meal filters, but cannot answer general questions or invent menu items."
    return {"reply": " ".join(notes) if notes else reply, "preferences": current, "changed": [], "can_search": False, "mode": "built_in"}
