"""Live location discovery, menus and scheduled hours from VT's public services."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from functools import lru_cache
from time import time
from zoneinfo import ZoneInfo
import requests

TZ = ZoneInfo("America/New_York")
BASE = "https://foodpro.students.vt.edu/menus/API"
HOURS = "https://apps.students.vt.edu/hours/Api/NonRestricted/FoodProCentersOpen/readByFoodPro"
NO_PREFERENCE = "Not sure / No preference"

@lru_cache(maxsize=4096)
def cached_json(url, params, bucket):
    response = requests.get(url, params=dict(params), timeout=12)
    response.raise_for_status()
    return response.json()

def get_json(url, params=()):
    return cached_json(url, tuple(params), int(time() // 300))

def scheduled_status(units, now):
    if not isinstance(units, list):
        return {"status": "unknown", "status_label": "Hours unavailable", "hours": []}
    # This is the same schedule endpoint used by VT's menu homepage.
    # A successful empty schedule is distinct from a failed request.
    if not units:
        return {"status": "closed", "status_label": "Closed today (no scheduled service)", "hours": []}
    windows, labels = [], []
    try:
        for unit in units:
            if "hours" not in unit:
                raise ValueError("Missing hours")
            for row in unit["hours"]:
                start_day = row.get("start", now.date().isoformat())[:10]
                end_day = row.get("end", start_day)[:10]
                if not start_day <= now.date().isoformat() <= end_day:
                    continue
                opening = datetime.combine(now.date(), datetime.strptime(row["open_time"], "%H:%M:%S").time(), TZ)
                closing = datetime.combine(now.date(), datetime.strptime(row["close_time"], "%H:%M:%S").time(), TZ)
                if closing <= opening:
                    closing += timedelta(days=1)
                windows.append((opening, closing))
                labels.append(f'{unit.get("name", "")}: {row.get("label", "")} {row.get("title", "")}'.strip())
        opened = any(a <= now < b for a, b in windows)
        upcoming = sorted(a for a, b in windows if a > now)
        return {"status": "open" if opened else "closed",
                "status_label": "Open now (scheduled)" if opened else (
                    "Closed now — opens " + upcoming[0].strftime("%I:%M %p").lstrip("0") if upcoming else "Closed today / finished service"),
                "hours": labels}
    except (KeyError, ValueError, TypeError):
        return {"status": "unknown", "status_label": "Hours unavailable", "hours": []}

class VTDiningConnector:
    NO_PREFERENCE = NO_PREFERENCE
    def directory(self):
        data = get_json(BASE + "/Locations.aspx")
        if not isinstance(data, list) or not data:
            raise ValueError("No location directory")
        return [{"id": str(row["locationNum"]), "name": row["name"].strip()} for row in data]

    def get_menu(self, location_id, day):
        data = get_json(BASE + "/MenuAtLocation.aspx", (("locationNum", location_id), ("dtdate", day)))
        if not isinstance(data, dict) or not isinstance(data.get("meals"), list):
            raise ValueError("Invalid menu response")
        return data

    def location_status(self, location, now):
        info = dict(location)
        info["hours_url"] = "https://foodpro.students.vt.edu/menus/"
        try:
            units = get_json(f'{HOURS}/{location["id"]}/{now.date().isoformat()}')
            info.update(scheduled_status(units, now))
            # Check overnight carry-over rather than assuming yesterday ended at midnight.
            if now.hour < 6:
                yesterday = now - timedelta(days=1)
                previous = get_json(f'{HOURS}/{location["id"]}/{yesterday.date().isoformat()}')
                for unit in previous if isinstance(previous, list) else []:
                    for row in unit.get("hours", []):
                        a = datetime.combine(yesterday.date(), datetime.strptime(row["open_time"], "%H:%M:%S").time(), TZ)
                        b = datetime.combine(yesterday.date(), datetime.strptime(row["close_time"], "%H:%M:%S").time(), TZ)
                        if b <= a and a <= now < b + timedelta(days=1):
                            info.update(status="open", status_label="Open now (overnight schedule)")
            info["announcements"] = [str(a.get("title") or a.get("message") or a.get("description") or "See official hours announcement") for u in units for a in u.get("announcements", [])]
        except (requests.RequestException, ValueError, TypeError, KeyError):
            info.update(status="unknown", status_label="Hours unavailable", hours=[], announcements=[])
        day = f"{now.month}/{now.day}/{now.year}"
        try:
            menu = self.get_menu(location["id"], day)
            count = sum(len(s.get("recipes", [])) for m in menu["meals"] for s in m.get("sections", []))
            info["menu_status"] = "available" if count else "no_menu"
            info["menu_item_count"] = count
        except (requests.RequestException, ValueError, TypeError):
            info.update(menu_status="unavailable", menu_item_count=0)
        return info

    def location_catalog(self, now=None):
        now = now or datetime.now(TZ)
        directory = self.directory()
        with ThreadPoolExecutor(max_workers=6) as pool:
            return list(pool.map(lambda loc: self.location_status(loc, now), directory))

    def search_foods(self, selected, catalog, now, meal_period=None):
        # Legacy preferences still resolve to the matching halls.
        aliases = {"Dietrick Hall": ["15", "71", "72", "07"], "D2": ["15"],
            "Owens Hall": ["09", "39"], "Turner Place": ["14"], "West End / Cochrane Hall": ["16"]}
        ids = aliases.get(selected, [selected])
        locations = [loc for loc in catalog if selected == NO_PREFERENCE or loc["id"] in ids or loc["name"] == selected]
        if not locations:
            raise ValueError("Unknown dining location. Refresh the location list.")
        day = f"{now.month}/{now.day}/{now.year}"
        foods, jobs, warnings = [], {}, []
        for loc in locations:
            if loc["menu_status"] != "available":
                warnings.append(f'{loc["name"]}: ' + ("menu unavailable" if loc["menu_status"] == "unavailable" else "no menu published for today"))
                continue
            menu = self.get_menu(loc["id"], day)
            for meal in menu["meals"]:
                if meal_period and meal.get("mealName", "").lower() != meal_period.replace("_", " "):
                    continue
                for section in meal.get("sections", []):
                    for recipe in section.get("recipes", []):
                        if not recipe.get("recipeId"):
                            continue
                        key = (loc["id"], str(recipe["recipeId"]), str(recipe.get("portionSize") or "1"))
                        jobs[key] = True
                        foods.append(dict(recipe_id=str(recipe["recipeId"]), name=recipe.get("name", ""),
                            location_id=loc["id"], location_name=loc["name"], meal=meal.get("mealName", ""),
                            menu_date=now.date().isoformat(), dietary_tags=recipe.get("legendImages", []),
                            allergens=recipe.get("allergens"), portion_size=recipe.get("portionSize"),
                            portion_unit=recipe.get("portionUnit"), label_key=key))
        def label(key):
            try:
                data = get_json(BASE + "/Label.aspx", (("locationNum", key[0]), ("dtdate", day), ("recNumAndPort", key[1] + "*" + key[2])))
                return {} if data.get("hasNoNutritionInformation") else data
            except (requests.RequestException, ValueError, TypeError, AttributeError):
                return None
        with ThreadPoolExecutor(max_workers=8) as pool:
            labels = dict(zip(jobs, pool.map(label, jobs)))
        failed = sum(value is None for value in labels.values())
        if failed:
            warnings.append(f"{failed} nutrition labels could not be loaded. Unknown values cannot satisfy nutrition limits.")
        for food in foods:
            data = labels[food.pop("label_key")] or {}
            for field, source in {"calories":"calories", "protein":"proteinGrams", "carbs":"totalCarbohydratesGrams", "fat":"totalFatGrams", "sugar":"sugarsGrams"}.items():
                food[field] = data.get(source)
            # Include allergen information from the nutrition label when the menu omits it.
            food["allergens"] = food["allergens"] or data.get("allergens")
        return foods, locations, warnings
