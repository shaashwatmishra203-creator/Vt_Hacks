import unittest
from unittest.mock import patch
from datetime import datetime
import requests
from fastapi.testclient import TestClient
from main import app
from models.recommendation import RecommendationRequest
from services.recommendation import RecommendationService
from services.vt_dining import scheduled_status, TZ

FOOD = dict(recipe_id='fixture', name='Test fixture', location_id='15', location_name='D2', meal='Dinner',
    menu_date='2026-09-20', calories=540, protein=42, carbs=48, fat=18, sugar=None,
    dietary_tags=['vegan'], allergens='Soybeans', portion_size='1', portion_unit='serving')
LOCATION = dict(id='15', name='D2', menu_status='available', status='closed', status_label='Closed now')

class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)
        self.catalog = patch('main.VTDiningConnector.location_catalog', return_value=[LOCATION]).start()
        self.search = patch('main.VTDiningConnector.search_foods', return_value=([FOOD], [LOCATION], [])).start()
        self.addCleanup(patch.stopall)

    def test_form_contract(self):
        response = self.client.post('/recommend', json=dict(max_calories=600, min_protein_g=40,
            dining_location='15', closest_dining_location='Turner Place', meal_period='dinner', dietary_restrictions=['vegetarian']))
        self.assertEqual(response.status_code, 200)
        item = response.json()['recommendations'][0]
        self.assertIsNone(item['nutrition']['sugar_g'])
        self.assertEqual(item['portion_size'], '1')
        self.assertEqual(response.json()['location_statuses'][0]['status'], 'closed')

    def test_missing_nutrition_is_not_zero(self):
        result = RecommendationService().recommend(RecommendationRequest(max_sugar_g=20), [FOOD])
        self.assertEqual(result.status, 'no_exact_matches')

    def test_allergy_alias_and_missing_information(self):
        for info in ('Milk', ''):
            result = RecommendationService().recommend(RecommendationRequest(allergies=['dairy']), [dict(FOOD, allergens=info)])
            self.assertEqual(result.status, 'no_exact_matches')

    def test_adjustment_then_retry(self):
        initial = self.client.post('/recommend', json={'max_calories': 500}).json()
        option = next(a for a in initial['adjustments'] if a['id'] == 'max_calories')
        self.assertEqual(option['matching_option_count'], 1)
        retry = self.client.post('/recommend', json={'max_calories': 500 + option['change']['max_calories']})
        self.assertEqual(retry.json()['status'], 'matches_found')

    def test_outage_is_not_no_matches(self):
        self.catalog.side_effect = requests.RequestException('offline')
        self.assertEqual(self.client.post('/recommend', json={}).status_code, 503)

    def test_empty_menu_is_not_constraint_failure(self):
        self.search.return_value = ([], [dict(LOCATION, menu_status='no_menu')], [])
        response = self.client.post('/recommend', json={})
        self.assertEqual(response.json()['status'], 'no_menu_available')

    def test_all_menus_unavailable_is_outage(self):
        self.search.return_value = ([], [dict(LOCATION, menu_status='unavailable')], [])
        self.assertEqual(self.client.post('/recommend', json={}).status_code, 503)

    def test_negative_validation(self):
        self.assertEqual(self.client.post('/recommend', json={'max_calories': -1}).status_code, 422)

    def test_cors(self):
        response = self.client.options('/recommend', headers={'Origin': 'http://localhost:3000',
            'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'content-type'})
        self.assertEqual(response.headers['access-control-allow-origin'], 'http://localhost:3000')

    def test_hours_open_closed_unknown(self):
        units = [dict(name='Test', hours=[dict(open_time='09:00:00', close_time='20:00:00', title='9 AM - 8 PM')])]
        self.assertEqual(scheduled_status(units, datetime(2026,9,20,10,tzinfo=TZ))['status'], 'open')
        self.assertEqual(scheduled_status(units, datetime(2026,9,20,7,tzinfo=TZ))['status'], 'closed')
        self.assertEqual(scheduled_status([{}], datetime.now(TZ))['status'], 'unknown')
        self.assertEqual(scheduled_status([], datetime.now(TZ))['status'], 'closed')

    def test_empty_actual_meal_does_not_match_dinner(self):
        result = RecommendationService().recommend(RecommendationRequest(meal_period='dinner'), [dict(FOOD, meal='')])
        self.assertEqual(result.status, 'no_exact_matches')

if __name__ == '__main__':
    unittest.main()
