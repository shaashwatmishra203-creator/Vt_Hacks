# GobbleGood backend (integrated version 0.5.0)

Python 3.10+ required. The matching frontend is included alongside this folder.

## Run locally

From backend:
```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m uvicorn main:app --host 127.0.0.1 --port 8000
```
On Namitha's Mac dependencies are already installed. Only the last command is needed to restart.
In another terminal, run `npm run dev` from frontend (first install with `npm install` on a new machine).
Keep both terminals running. Open http://localhost:3000. API docs: http://localhost:8000/docs.

## Live data and hours

The connector discovers every location from VT's public Locations.aspx endpoint. As verified September 20, 2026 this lists 12 locations. It loads each location's menu independently; not all locations publish menus every day.

Source URLs:
- https://foodpro.students.vt.edu/menus/API/Locations.aspx
- https://foodpro.students.vt.edu/menus/API/MenuAtLocation.aspx
- https://foodpro.students.vt.edu/menus/API/Label.aspx
- https://apps.students.vt.edu/hours/Api/NonRestricted/FoodProCentersOpen/readByFoodPro/

The hours endpoint is the same endpoint used by VT's menu homepage. A successful empty schedule displays closed/no scheduled service. Request failures or malformed schedules display Hours unavailable. Opening status uses America/New_York and includes overnight carry-over. Status is scheduled service, not an occupancy sensor; official notices may change operations.

Menus and opening status are separate. A menu can exist for a closed hall or later meal period. Results explicitly show status rather than silently excluding every hall before breakfast.

## API

GET /dining-locations returns location objects: id, name, status, status_label, hours, menu_status, menu_item_count, announcements, hours_url.

POST /recommend accepts optional numeric nutrition constraints, dietary_restrictions, allergies, meal_period, dining_location (source ID, or Not sure / No preference for all), closest_dining_location (optional origin name), and priority.

The response includes recommendations, signed-delta adjustments, location_statuses, warnings, and status:
- matches_found: results meeting filters
- no_exact_matches: menu exists but constraints did not match
- no_menu_available: no published items for the selected location/meal period

Source failures return 503 or partial-data warnings, never fabricated meals. A failed nutrition label stays unknown and does not pass numeric filters. Menu data is cached for five minutes; label fetches use at most eight workers per request.

## Walking and other limits

Closest location is used only in Google Maps walking-direction links. No in-app walking time calculation or distance ranking exists. No device location is collected. Google Maps determines routing after the student opens the link.

Results are individual servings, not combined meals. Both supported priorities rank by protein then calories. Dietary tags must come from the source; vegan satisfies vegetarian. Allergens are matched from source text, with common aliases such as dairy/milk. Missing allergen data excludes an item when allergy filters are active. This is not a guarantee of allergy safety; substitutions and cross-contact need dining staff confirmation.

The built-in meal chatbot uses POST /chat to interpret simple meal requests and return reviewable search filters. It is rule-based, not generative AI or HokieAI. No API key is required. Allergy changes use the survey. Run tests with: .venv/bin/python -m unittest test_chat test_integration

## Testing

```sh
.venv/bin/python -m pip install -r requirements-dev.txt
.venv/bin/python -m unittest test_integration -v
```

Eleven tests cover contracts, status distinctions, unknown nutrition, allergies, adjustments, errors, validation and CORS. Next.js build and lint pass. Live all-location and West End dinner searches returned recommendations on September 20, 2026.

## Deployment

GitHub stores source; it does not run these servers automatically. Set NEXT_PUBLIC_API_BASE_URL to the deployed backend HTTPS URL before building the frontend. Set FRONTEND_ORIGINS on the backend to the deployed frontend HTTPS URL. Local defaults support localhost:3000, localhost:3001 and 127.0.0.1:3000.
