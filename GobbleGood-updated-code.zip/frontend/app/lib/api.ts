export type Preferences = {
  max_calories: number | null;
  min_protein_g: number | null;
  max_carbs_g: number | null;
  max_fat_g: number | null;
  max_sugar_g: number | null;
  dietary_restrictions: string[];
  allergies: string[];
  meal_period: string | null;
  dining_location: string;
  closest_dining_location?: string | null;
  priority: string;
};
export type Meal = {
  location_id: string;
  id: string; food_name: string; location_name: string; meal_period: string | null;
  nutrition: { calories: number | null; protein_g: number | null; carbs_g: number | null; fat_g: number | null; sugar_g: number | null };
  dietary_tags: string[]; allergens: string[]; menu_date: string;
  portion_size?: string; portion_unit?: string;
  match_explanation: string[];
};
export type Adjustment = { id: string; label: string; change: Partial<Record<keyof Preferences, number>>; matching_option_count: number };
export type RecommendationResponse = {
  status: "matches_found" | "no_exact_matches" | "no_menu_available"; data_source: string;
  location_statuses: DiningLocation[]; warnings: string[];
  generated_at: string; recommendations: Meal[]; adjustments: Adjustment[];
};
export type DiningLocation = { id: string; name: string; status: "open" | "closed" | "unknown"; status_label: string; hours: string[]; menu_status: string; menu_item_count: number; hours_url: string; announcements: string[] };
export async function getLocations(): Promise<DiningLocation[]> {
  const response = await fetch(API_BASE + "/dining-locations", { signal: AbortSignal.timeout(45000) });
  if (!response.ok) throw new Error("Dining locations could not be loaded. Check the backend and retry.");
  const data = await response.json();
  if (!Array.isArray(data.locations) || data.locations.some((item: unknown) => !item || typeof item !== "object")) throw new Error("Restart the backend to load the updated dining directory.");
  return data.locations;
}
export const STORAGE_KEY = "dining-finder-preferences-v1";
export const API_BASE = (process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000").replace(/\/$/, "");

export async function recommend(preferences: Preferences, signal?: AbortSignal): Promise<RecommendationResponse> {
  const timeout = AbortSignal.timeout(120000);
  let response: Response;
  try {
    response = await fetch(API_BASE + "/recommend", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(preferences),
      signal: signal ? AbortSignal.any([signal, timeout]) : timeout,
    });
  } catch (error) {
    if (signal?.aborted) throw error;
    throw new Error("Could not reach the dining service. Check that the backend is running, then retry.");
  }
  const body = await response.json();
  if (!response.ok) {
    throw new Error(typeof body.detail === "string" ? body.detail : "Please check your preferences and try again.");
  }
  if (!Array.isArray(body.recommendations) || !Array.isArray(body.adjustments) ||
      !["matches_found", "no_exact_matches", "no_menu_available"].includes(body.status)) {
    throw new Error("The dining service returned an unexpected response.");
  }
  return body;
}
