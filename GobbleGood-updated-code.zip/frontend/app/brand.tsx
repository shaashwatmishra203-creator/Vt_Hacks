import Link from "next/link";

export function Bird({ className = "" }: { className?: string }) {
  return <svg className={className} viewBox="0 0 160 160" fill="none" aria-hidden="true">
    <path d="M77 104C20 117 5 76 26 64C2 33 33 10 54 40C49 2 88 0 89 37C108 8 139 27 121 57C159 46 170 86 130 105Z" fill="#e87722" stroke="#fff3dc" strokeWidth="5"/>
    <path d="M80 104C42 90 31 66 40 58M87 95L75 38M96 100L119 65" stroke="#ffd58a" strokeWidth="5" strokeLinecap="round"/>
    <ellipse cx="83" cy="108" rx="39" ry="34" fill="#861f41"/>
    <path d="M55 101Q75 93 79 119Q61 130 55 101" fill="#af3858"/>
    <path d="M99 98V66" stroke="#861f41" strokeWidth="30" strokeLinecap="round"/>
    <circle cx="103" cy="60" r="23" fill="#861f41"/>
    <path d="M118 61L142 70L120 79Z" fill="#ffbd59"/>
    <path d="M115 76Q125 102 110 99Q101 93 115 76" fill="#df4f45"/>
    <circle cx="109" cy="56" r="6" fill="white"/><circle cx="111" cy="56" r="3" fill="#2d2028"/>
    <path d="M71 137V148L58 151M95 137V148L109 151" stroke="#e87722" strokeWidth="7" strokeLinecap="round"/>
  </svg>;
}

export default function Brand() {
  return <Link className="brand" href="/" aria-label="GobbleGood home"><Bird /><span>Gobble<span className="brand-good">Good</span><small>GOOD FOOD. HOKIE MOOD.</small></span></Link>;
}

export function LoadingBird({ compact = false }: { compact?: boolean }) {
  return <div className={"bird-loader" + (compact ? " compact" : "")} role="status">
    <div className="bird-stage"><Bird className="jumping-bird" /><span className="bird-shadow" /></div>
    <div><strong>{compact ? "Getting campus ready…" : "Good things are on the menu…"}</strong><p>{compact ? "Checking dining locations and hours." : "Checking today’s menus and nutrition labels. The first search can take a minute."}</p></div>
  </div>;
}
