"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import Locations from "../locations";
import Brand, { LoadingBird } from "../brand";
import { recommend, STORAGE_KEY, type Preferences, type RecommendationResponse, type Adjustment } from "../lib/api";

export default function ResultsPage() {
  const [result, setResult] = useState<RecommendationResponse | null>(null);
  const [preferences, setPreferences] = useState<Preferences | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [retry, setRetry] = useState(0);
  useEffect(() => {
    const controller = new AbortController();
    async function load() {
      try {
        const saved = sessionStorage.getItem(STORAGE_KEY);
        if (!saved) throw new Error("Choose your preferences on the home page first.");
        const request = JSON.parse(saved) as Preferences;
        const response = await recommend(request, controller.signal);
        if (!controller.signal.aborted) { setPreferences(request); setResult(response); }
      } catch (error) {
        if (!controller.signal.aborted) setError(error instanceof Error ? error.message : "The search failed.");
      } finally { if (!controller.signal.aborted) setLoading(false); }
    }
    void load();
    return () => controller.abort();
  }, [retry]);

  async function adjust(adjustment: Adjustment) {
    if (!preferences || loading) return;
    const next = { ...preferences };
    for (const [key, delta] of Object.entries(adjustment.change)) {
      if (["max_calories", "min_protein_g", "max_carbs_g", "max_fat_g", "max_sugar_g"].includes(key)) {
        const field = key as "max_calories";
        if (typeof next[field] === "number" && typeof delta === "number")
          next[field] = Math.max(0, next[field]! + delta);
      }
    }
    setLoading(true); setError(""); setResult(null);
    try {
      sessionStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      const response = await recommend(next);
      setPreferences(next); setResult(response);
    } catch (error) { setError(error instanceof Error ? error.message : "The search failed."); }
    finally { setLoading(false); }
  }
  return <main className="results-page">
    <nav><Brand />
      <Link className="sidekick-button" href="/#preferences">Update preferences</Link></nav>
    <section className="results-hero"><p className="eyebrow">TODAY’S MENU</p><h1>Find your next bite.</h1>
      <p>Today’s VT menus, filtered by your preferences. Opening status comes from VT’s hours service; menus can include items served later today.</p></section>
    <section className="results-content" aria-busy={loading}>
      {loading && <LoadingBird />}
      {error && <section className="no-match-card"><h2>We couldn’t complete your search.</h2><p role="alert">{error}</p>
        <button className="demo-toggle" onClick={() => { setError(""); setResult(null); setLoading(true); setRetry(n => n + 1); }}>Retry search</button>
        <p><Link href="/#preferences">Back to preferences</Link></p></section>}
      {!loading && !error && result && <>
        <p className="field-note">Source: {result.data_source === "vt_dining" ? "VT Dining" : result.data_source} · Retrieved {new Date(result.generated_at).toLocaleString()}</p>
        {result.warnings?.map((warning, index) => <p role="status" className="field-note" key={index}>{warning}</p>)}
        {result.status === "no_menu_available" ? <section className="no-match-card"><h2>No menu for this selection.</h2><p>This is different from food failing your nutrition filters. Try another dining location or choose any meal period.</p><Link href="/#preferences">Change search</Link></section> : result.status === "no_exact_matches" ? <section className="no-match-card">
          <p className="eyebrow">NO EXACT MATCHES</p><h2>Try a small adjustment.</h2>
          <p>No items in the connected menu meet all your filters. Missing nutrition or dietary labels can also exclude an item.</p>
          <div className="adjustment-list">{result.adjustments.map(adjustment => <button key={adjustment.id} className="adjustment-button" onClick={() => void adjust(adjustment)} disabled={loading}>
            <span>{adjustment.label}</span><strong>{adjustment.matching_option_count} options</strong>
          </button>)}</div>
          <p><Link href="/#preferences">Edit your preferences</Link></p>
        </section> : <>
          <div className="results-summary"><p className="eyebrow">{result.recommendations.length} OPTIONS SHOWN</p><h2>Sorted by protein, then calories.</h2></div>
          <div className="recommendation-list">{result.recommendations.map((meal, index) => <article className="recommendation-card" key={meal.id + meal.meal_period + index}>
            <div className="recommendation-topline"><p>{meal.location_name}</p><span>{meal.meal_period} · {meal.menu_date}</span></div>
            <p className="field-note">{result.location_statuses?.find(location => location.id === meal.location_id)?.status_label || "Hours unavailable"}</p>
            <h3>{meal.food_name}</h3>
            <p className="field-note">Per listed serving: {meal.portion_size || "Not provided"} {meal.portion_unit || ""}</p>
            <div className="tag-list">{meal.dietary_tags.map(tag => <span className="tag" key={tag}>{tag}</span>)}</div>
            <div className="nutrition-grid">{([
              ["Calories", meal.nutrition.calories, ""], ["Protein", meal.nutrition.protein_g, "g"],
              ["Carbs", meal.nutrition.carbs_g, "g"], ["Fat", meal.nutrition.fat_g, "g"], ["Sugar", meal.nutrition.sugar_g, "g"],
            ] as const).map(([label, value, unit]) => <div key={label}><strong>{value == null ? "Unknown" : value + unit}</strong><span>{label}</span></div>)}</div>
            <p className="allergen-line"><strong>Listed allergens:</strong> {meal.allergens.length ? meal.allergens.join(", ") : "Not provided — confirm with staff"}</p>
            <p className="field-note">Listed on the menu; availability and cross-contact must be confirmed with dining staff.</p>
            <a target="_blank" rel="noreferrer" href={"https://www.google.com/maps/dir/?api=1&travelmode=walking&destination=" + encodeURIComponent(meal.location_name + ", Virginia Tech, Blacksburg VA") + (preferences?.closest_dining_location ? "&origin=" + encodeURIComponent(preferences.closest_dining_location + ", Virginia Tech, Blacksburg VA") : "")}>Walking directions in Google Maps</a>
          </article>)}</div>
        </>}
        {result.location_statuses?.length > 0 && <Locations locations={result.location_statuses} />}
      </>}
    </section>
  </main>;
}
