"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { STORAGE_KEY, getLocations, type DiningLocation, type Preferences } from "./lib/api";
import Locations from "./locations";
import Brand, { Bird, LoadingBird } from "./brand";
import Sidekick from "./sidekick";

const nutritionFields = [
  ["max_calories", "Maximum calories", "650"],
  ["min_protein_g", "Minimum protein (g)", "30"],
  ["max_carbs_g", "Maximum carbs (g)", "75"],
  ["max_fat_g", "Maximum fat (g)", "25"],
  ["max_sugar_g", "Maximum sugar (g)", "20"],
] as const;

export default function Home() {
  const router = useRouter();
  const formRef = useRef<HTMLFormElement>(null);
  const [showSidekick, setShowSidekick] = useState(false);
  const [error, setError] = useState("");
  const [locations, setLocations] = useState<DiningLocation[]>([]);
  const [locationError, setLocationError] = useState("");
  const [catalogRetry, setCatalogRetry] = useState(0);
  useEffect(() => {
    let active = true;
    getLocations().then(data => { if (active) setLocations(data); }).catch(error => { if (active) setLocationError(error.message); });
    return () => { active = false; };
  }, [catalogRetry]);

  useEffect(() => {
    try {
      const saved = sessionStorage.getItem(STORAGE_KEY);
      if (!saved || !formRef.current) return;
      const data = JSON.parse(saved) as Preferences;
      for (const [name, value] of Object.entries(data)) {
        const input = formRef.current.elements.namedItem(name);
        if (input instanceof RadioNodeList) input.value = String(value);
        else if (input instanceof HTMLInputElement || input instanceof HTMLSelectElement) {
          const legacy: Record<string, string> = { "Dietrick Hall": "15", "Turner Place": "14", "Owens Hall": "39", "West End / Cochrane Hall": "16" };
          input.value = name === "dining_location" ? legacy[String(value)] || String(value) : Array.isArray(value) ? value.join(", ") : String(value ?? "");
        }
      }
    } catch { /* A new search still works if saved preferences are unavailable. */ }
  }, [locations]);

  function getPreferences(): Preferences {
    const values = new FormData(formRef.current!);
    const number = (name: string) => values.get(name) === "" ? null : Number(values.get(name));
    const dietary = String(values.get("dietary_restrictions") || "");
    const preferences: Preferences = {
      max_calories: number("max_calories"), min_protein_g: number("min_protein_g"),
      max_carbs_g: number("max_carbs_g"), max_fat_g: number("max_fat_g"),
      max_sugar_g: number("max_sugar_g"),
      dietary_restrictions: dietary ? [dietary] : [],
      allergies: String(values.get("allergies") || "").split(",").map(s => s.trim()).filter(Boolean),
      meal_period: String(values.get("meal_period") || "") || null,
      dining_location: String(values.get("dining_location")),
      closest_dining_location: String(values.get("closest_dining_location") || "") || null,
      priority: String(values.get("priority") || "balanced"),
    };
    return preferences;
  }

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const preferences = getPreferences();
    try {
      sessionStorage.setItem(STORAGE_KEY, JSON.stringify(preferences));
      router.push("/results");
    } catch { setError("Allow browser storage to keep your preferences during this search."); }
  }

  return (
    <main>
      <nav>
        <Brand />
        <button className="sidekick-button" onClick={() => setShowSidekick(!showSidekick)} aria-expanded={showSidekick}>Ask GobbleGood</button>
      </nav>
      <section className="hero">
        <div className="hero-copy"><p className="eyebrow">A LITTLE HOKIE SPIRIT. A BETTER BITE.</p>
        <h1>Eat well.<br /><em>Gobble happy.</em></h1>
        <p className="hero-text">Your campus. Your cravings. Find today’s Virginia Tech menu options that fit the way you want to eat.</p>
        <a className="primary-button" href="#preferences">Find my next bite <span aria-hidden="true">↗</span></a><p className="hero-footnote">Live menus · Nutrition filters · Dining hall hours</p></div><div className="hero-art"><span className="art-caption">YOUR NEXT GOOD BITE</span><Bird /><span className="art-sticker">Made for<br />hungry Hokies.</span></div>
      </section>
      <section className="intro" id="preferences">
        <div><p className="eyebrow">START HERE</p><h2>Tell us what matters today.</h2></div>
        <p>Set your nutrition limits, check dining hall hours, and search today’s menus across campus.</p>
      </section>
      <section className="preference-form">
        <div className="form-heading">
          <p className="eyebrow">MEAL PREFERENCES</p><h2>Build your meal search.</h2>
          <p>Leave nutrition fields empty if you have no limit. Values apply to one listed serving, not a combined meal.</p>
        </div>
        <form ref={formRef} onSubmit={submit}>
          {locationError && <p role="alert">{locationError} <button type="button" onClick={() => { setLocationError(""); setCatalogRetry(n => n + 1); }}>Retry locations</button></p>}
          {!locations.length && !locationError && <LoadingBird compact />}
          <fieldset><legend>Nutrition goals</legend><div className="form-grid">
            {nutritionFields.map(([name, label, example]) => <label key={name}>{label}<input name={name} type="number" min="0" step="any" placeholder={"Example: " + example} /></label>)}
          </div></fieldset>
          <fieldset><legend>Dining needs</legend><div className="form-grid">
            <label>Dietary restriction<select name="dietary_restrictions" defaultValue="">
              <option value="">No restriction</option><option value="vegetarian">Vegetarian</option>
              <option value="vegan">Vegan</option><option value="halal">Halal</option><option value="gluten-free">Gluten-free</option>
            </select></label>
            <p className="field-note">Only explicit dietary labels from the menu satisfy a restriction. Missing labels may mean no matches.</p>
            <label>Allergies to filter<input name="allergies" placeholder="Example: peanuts, milk" /></label>
            <p className="field-note">Separate entries with commas. Menu allergen filtering cannot guarantee safety or detect cross-contact. Confirm with dining staff.</p>
            <label>Meal period<select name="meal_period" defaultValue="">
              <option value="">Any meal period</option><option value="breakfast">Breakfast</option><option value="lunch">Lunch</option>
              <option value="dinner">Dinner</option><option value="late_night">Late night</option>
            </select></label>
            <label>Which dining location are you closest to?<select name="closest_dining_location" defaultValue="">
              <option value="">Not sure</option>
              {locations.map(location => <option key={location.id} value={location.name}>{location.name}</option>)}
            </select></label>
            <label>Where would you like to eat?<select name="dining_location" defaultValue="Not sure / No preference" required>
              <option value="Not sure / No preference">Search all dining locations</option>
              {locations.map(location => <option key={location.id} value={location.id}>{location.name} — {location.status_label}</option>)}
            </select></label>
            <p className="field-note">Your closest hall is the starting point for walking-directions links. The search location controls which menus to check. No device location is collected.</p>
            <label>Maximum walking time (minutes)<input type="number" disabled placeholder="Not available yet" /></label>
            <p className="field-note">Result cards link to walking directions. This app cannot yet calculate or filter walking times.</p>
          </div></fieldset>
          <fieldset><legend>What should matter most?</legend><div className="priority-options">
            <label><input type="radio" name="priority" value="balanced" defaultChecked /> Balanced</label>
            <label><input type="radio" name="priority" value="nutrition" /> Better nutrition</label>
            <label><input type="radio" name="priority" value="convenience" disabled /> Shorter walking time — coming later</label>
          </div><p className="field-note">Both available modes currently rank by protein, then calories.</p></fieldset>
          <button className="primary-button" type="submit" disabled={!locations.length}>See meal options</button>
          {error && <p role="alert">{error}</p>}
          <p className="field-note">Searches use live VT menu data. Availability can change throughout the day.</p>
        </form>
        {locations.length > 0 && <Locations locations={locations} />}
      </section>
      {showSidekick && <Sidekick close={() => setShowSidekick(false)} getPreferences={getPreferences} locations={locations} />}
    </main>
  );
}
