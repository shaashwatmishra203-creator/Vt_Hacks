import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "GobbleGood | Your next good bite",
  description: "Find Virginia Tech dining menu items that fit your preferences.",
  icons: { icon: "/gobblegood.svg" },
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
