import type { DiningLocation } from "./lib/api";

export default function Locations({ locations }: { locations: DiningLocation[] }) {
  return <section className="location-statuses" aria-label="Dining hall status">
    <h2>Dining hall status</h2>
    <p className="field-note">Scheduled opening status in Blacksburg time, separate from menu availability. A closed hall may have a menu for later today. Check official notices for changes.</p>
    {locations.map(location => <details key={location.id} className="location-row">
      <summary><strong>{location.name}</strong><span className={"status-" + location.status}>{location.status_label}</span></summary>
      <p>{location.menu_status === "available" ? location.menu_item_count + " menu entries published today" : location.menu_status === "no_menu" ? "No menu published for today" : "Menu service unavailable — retry later"}</p>
      {location.hours.map((hours, index) => <p key={index}>{hours}</p>)}
      {location.announcements?.map((notice, index) => <p key={index}>{notice}</p>)}
      <a href={location.hours_url} target="_blank" rel="noreferrer">Check official VT hours and notices</a>
    </details>)}
  </section>;
}
