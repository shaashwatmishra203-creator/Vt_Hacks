"use client";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { API_BASE, STORAGE_KEY, type Preferences, type DiningLocation } from "./lib/api";

type Reply = { reply: string; preferences: Preferences; changed: string[]; can_search: boolean };
type Message = { role: "user" | "assistant"; text: string };

export default function Sidekick({ close, getPreferences, locations }: {
  close: () => void; getPreferences: () => Preferences; locations: DiningLocation[];
}) {
  const router = useRouter();
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<Message[]>([{ role: "assistant", text: "Hi! Tell me your meal period and nutrition limits. Try: dinner under 650 calories with at least 30g protein at West End." }]);
  const [draft, setDraft] = useState<Preferences | null>(null);
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const input = useRef<HTMLInputElement>(null);
  const log = useRef<HTMLDivElement>(null);
  const controller = useRef<AbortController | null>(null);
  useEffect(() => { input.current?.focus(); return () => controller.current?.abort(); }, []);
  useEffect(() => { if (log.current) log.current.scrollTop = log.current.scrollHeight; }, [messages, busy]);

  async function send(event: FormEvent) {
    event.preventDefault();
    const text = message.trim();
    if (!text || busy) return;
    setBusy(true); setError(""); setReady(false);
    setMessages(previous => [...previous.slice(-19), { role: "user", text }]);
    setMessage("");
    controller.current = new AbortController();
    try {
      const response = await fetch(API_BASE + "/chat", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, preferences: draft || getPreferences() }),
        signal: AbortSignal.any([controller.current.signal, AbortSignal.timeout(15000)]),
      });
      if (!response.ok) throw new Error(response.status === 404 ? "Restart the backend to enable the new chatbot." : "The chatbot could not process that request. Try a shorter message.");
      const data: Reply = await response.json();
      if (!data.preferences || typeof data.reply !== "string") throw new Error("The chatbot returned an unexpected response.");
      setDraft(data.preferences); setReady(data.can_search);
      setMessages(previous => [...previous, { role: "assistant", text: data.reply }]);
    } catch (error) {
      if (!controller.current?.signal.aborted) {
        setMessage(text);
        setError(error instanceof TypeError ? "Could not reach the chatbot. Check that the backend is running and try again." : error instanceof Error ? error.message : "Chat failed. Please retry.");
      }
    } finally { setBusy(false); }
  }

  function search() {
    if (!draft || !ready) return;
    try { sessionStorage.setItem(STORAGE_KEY, JSON.stringify(draft)); router.push("/results"); }
    catch { setError("Allow browser storage to search with these preferences."); }
  }
  const labels = [["max_calories", "Calories ≤"], ["min_protein_g", "Protein ≥"], ["max_carbs_g", "Carbs ≤"], ["max_fat_g", "Fat ≤"], ["max_sugar_g", "Sugar ≤"]] as const;
  return <aside className="sidekick-panel" aria-label="GobbleGood meal chatbot" onKeyDown={event => { if (event.key === "Escape") close(); }}>
    <div className="sidekick-header"><div><p className="eyebrow">YOUR MEAL SIDEKICK</p><h2>Let’s talk food.</h2></div><button className="close-button" onClick={close} aria-label="Close chatbot">×</button></div>
    <p className="chat-disclosure">Built-in meal assistant · understands simple meal requests. Not generative AI or HokieAI.</p>
    <div className="chat-log" ref={log} role="log" aria-live="polite" aria-label="Chat messages">
      {messages.map((item, index) => <p className={"chat-bubble " + item.role} key={index}><span className="chat-speaker">{item.role === "user" ? "You" : "GobbleGood"}</span>{item.text}</p>)}
      {busy && <p role="status">Reading your meal preferences…</p>}
    </div>
    {draft && ready && <div className="chat-preview"><strong>Review your search</strong><ul>
      {labels.map(([key, label]) => draft[key] != null && <li key={key}>{label} {draft[key]}{key === "max_calories" ? " kcal" : "g"}</li>)}
      <li>Meal: {draft.meal_period?.replace("_", " ") || "Any"}</li>
      <li>Dining: {locations.find(location => location.id === draft.dining_location)?.name || draft.dining_location}</li>
      <li>Dietary labels: {draft.dietary_restrictions.join(", ") || "None"}</li>
      <li>Allergy filters: {draft.allergies.join(", ") || "None"}</li>
    </ul><button className="primary-button" onClick={search} disabled={busy}>Search live menus ↗</button></div>}
    {error && <p role="alert" className="chat-error">{error}</p>}
    <form className="chat-form" onSubmit={send}>
      <input ref={input} aria-label="Message GobbleGood" value={message} onChange={event => setMessage(event.target.value)} placeholder="Dinner under 650 calories…" maxLength={1000} disabled={busy} />
      <button type="submit" disabled={busy || !message.trim()}>Send</button>
    </form>
    <p className="field-note">Follow up with another limit, or say “reset filters”. Use the survey for allergy changes.</p>
  </aside>;
}
