"use client";

import { useEffect, useState } from "react";

type NutritionResponse = {
  calories?: number | null;
  protein_g?: number | null;
  carbs_g?: number | null;
  fat_g?: number | null;
  sugar_g?: number | null;
};

type RecommendationItem = {
  id: string;
  food_name: string;
  location_name: string;
  meal_period?: string | null;
  nutrition: NutritionResponse;
  dietary_tags: string[];
  allergens: string[];
  match_explanation: string[];
};

type Adjustment = {
  id: string;
  label: string;
  matching_option_count: number;
};

type RecommendationResponse = {
  status: "matches_found" | "no_exact_matches";
  recommendations: RecommendationItem[];
  adjustments: Adjustment[];
};

export default function ResultsPage() {
  const [data, setData] = useState<RecommendationResponse | null>(null);
  const [loadedFromStorage, setLoadedFromStorage] = useState(false);

  useEffect(() => {
    const raw = sessionStorage.getItem("recommendations");
    if (raw) {
      try {
        setData(JSON.parse(raw));
      } catch {
        setData(null);
      }
    }
    setLoadedFromStorage(true);
  }, []);

  return (
    <main className="results-page">
      <nav>
        <a className="brand" href="/">
          <span className="brand-mark">VT</span>
          <span>Dining Finder</span>
        </a>

        <a className="sidekick-button" href="/">
          Update preferences
        </a>
      </nav>

      <section className="results-hero">
        <p className="eyebrow">MEAL RECOMMENDATIONS</p>
        <h1>
          {data?.status === "no_exact_matches"
            ? "Let’s find your closest match."
            : "Meals that fit your goals."}
        </h1>
        <p>Live results from the VT Dining backend.</p>
      </section>

      <section className="results-content">
        {!loadedFromStorage && <p>Loading…</p>}

        {loadedFromStorage && !data && (
          <div className="no-match-card">
            <p className="eyebrow">NO SEARCH YET</p>
            <h2>Go back and set your preferences first.</h2>
            <p>
              This page shows results from your last search. Head back to the
              form to run a new one.
            </p>
          </div>
        )}

        {data?.status === "no_exact_matches" && (
          <section className="no-match-card">
            <p className="eyebrow">NO EXACT MATCHES</p>
            <h2>Your current filters are very specific.</h2>
            <p>
              Choose one small adjustment, and search again using your
              updated preferences.
            </p>

            <div className="adjustment-list">
              {data.adjustments.map((adjustment) => (
                <div className="adjustment-button" key={adjustment.id}>
                  <span>{adjustment.label}</span>
                  <strong>
                    {adjustment.matching_option_count} options
                  </strong>
                </div>
              ))}
              {data.adjustments.length === 0 && (
                <p>No suggested adjustments — try loosening more filters.</p>
              )}
            </div>
          </section>
        )}

        {data?.status === "matches_found" && (
          <>
            <div className="results-summary">
              <p className="eyebrow">
                {data.recommendations.length} OPTIONS FOUND
              </p>
              <h2>Ranked for your preferences.</h2>
            </div>

            <div className="recommendation-list">
              {data.recommendations.map((meal) => (
                <article className="recommendation-card" key={meal.id}>
                  <div className="recommendation-topline">
                    <p>{meal.location_name}</p>
                    {meal.meal_period && <span>{meal.meal_period}</span>}
                  </div>

                  <h3>{meal.food_name}</h3>

                  <div className="tag-list">
                    {meal.dietary_tags.map((tag) => (
                      <span className="tag" key={tag}>
                        {tag}
                      </span>
                    ))}
                  </div>

                  <div className="nutrition-grid">
                    <div>
                      <strong>{meal.nutrition.calories ?? "—"}</strong>
                      <span>Calories</span>
                    </div>
                    <div>
                      <strong>{meal.nutrition.protein_g ?? "—"}g</strong>
                      <span>Protein</span>
                    </div>
                    <div>
                      <strong>{meal.nutrition.carbs_g ?? "—"}g</strong>
                      <span>Carbs</span>
                    </div>
                    <div>
                      <strong>{meal.nutrition.fat_g ?? "—"}g</strong>
                      <span>Fat</span>
                    </div>
                    <div>
                      <strong>{meal.nutrition.sugar_g ?? "—"}g</strong>
                      <span>Sugar</span>
                    </div>
                  </div>

                  {meal.allergens.length > 0 && (
                    <p className="allergen-line">
                      <strong>Allergens:</strong> {meal.allergens.join(", ")}
                    </p>
                  )}

                  {meal.match_explanation.length > 0 && (
                    <p className="allergen-line">
                      {meal.match_explanation.join(" · ")}
                    </p>
                  )}
                </article>
              ))}
            </div>
          </>
        )}
      </section>
    </main>
  );
}
