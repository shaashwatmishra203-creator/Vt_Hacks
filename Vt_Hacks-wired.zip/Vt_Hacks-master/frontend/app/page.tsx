"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { API_BASE_URL } from "./lib/api";

const NO_PREFERENCE = "Not sure / No preference";

export default function Home() {
  const router = useRouter();

  const [showSidekick, setShowSidekick] = useState(false);
  const [chatMessage, setChatMessage] = useState("");
  const [chatSubmitted, setChatSubmitted] = useState(false);

  // Dining locations, fetched from the backend so the dropdown
  // always matches what /recommend actually accepts.
  const [diningLocations, setDiningLocations] = useState<string[]>([
    NO_PREFERENCE,
  ]);

  // Form fields
  const [maxCalories, setMaxCalories] = useState("");
  const [minProtein, setMinProtein] = useState("");
  const [maxCarbs, setMaxCarbs] = useState("");
  const [maxFat, setMaxFat] = useState("");
  const [maxSugar, setMaxSugar] = useState("");
  const [dietaryRestriction, setDietaryRestriction] = useState("");
  const [allergies, setAllergies] = useState("");
  const [mealPeriod, setMealPeriod] = useState("");
  const [diningLocation, setDiningLocation] = useState(NO_PREFERENCE);
  const [priority, setPriority] = useState<
    "balanced" | "nutrition" | "convenience"
  >("balanced");

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch(`${API_BASE_URL}/dining-locations`)
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data.locations) && data.locations.length > 0) {
          setDiningLocations(data.locations);
          setDiningLocation(data.locations[data.locations.length - 1]);
        }
      })
      .catch(() => {
        // Backend not running yet — keep the "no preference" fallback.
      });
  }, []);

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    setSubmitting(true);
    setError("");

    const payload = {
      max_calories: maxCalories ? Number(maxCalories) : null,
      min_protein_g: minProtein ? Number(minProtein) : null,
      max_carbs_g: maxCarbs ? Number(maxCarbs) : null,
      max_fat_g: maxFat ? Number(maxFat) : null,
      max_sugar_g: maxSugar ? Number(maxSugar) : null,
      dietary_restrictions:
        dietaryRestriction && dietaryRestriction !== "None"
          ? [dietaryRestriction]
          : [],
      allergies: allergies
        .split(",")
        .map((a) => a.trim())
        .filter(Boolean),
      meal_period: mealPeriod
        ? (mealPeriod.toLowerCase().replace(" ", "_") as
            | "breakfast"
            | "lunch"
            | "dinner"
            | "late_night")
        : null,
      dining_location: diningLocation,
      priority,
    };

    try {
      const res = await fetch(`${API_BASE_URL}/recommend`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        throw new Error(`Backend returned ${res.status}`);
      }

      const data = await res.json();
      sessionStorage.setItem("recommendations", JSON.stringify(data));
      router.push("/results");
    } catch (err) {
      setError(
        "Couldn't reach the backend. Make sure it's running at " +
          API_BASE_URL +
          "."
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main>
      <nav>
        <div className="brand">
          <span className="brand-mark">VT</span>
          <span>Dining Finder</span>
        </div>

        <button
          className="sidekick-button"
          onClick={() => setShowSidekick(!showSidekick)}
        >
          Ask HokieFuel
        </button>
      </nav>

      <section className="hero">
        <p className="eyebrow">VIRGINIA TECH DINING</p>
        <h1>Find a meal that fits your day.</h1>
        <p className="hero-text">
          Filter Virginia Tech dining options by nutrition, dietary needs, and
          walking time.
        </p>

        <a className="primary-button" href="#preferences">
          Find My Meal
        </a>
      </section>

      <section className="intro" id="preferences">
        <div>
          <p className="eyebrow">START HERE</p>
          <h2>Tell us what matters today.</h2>
        </div>
        <p>
          Set your nutrition goals, dietary restrictions, preferred locations,
          and walking limit. We’ll use this information to rank dining options.
        </p>
      </section>

      <section className="preference-form">
        <div className="form-heading">
          <p className="eyebrow">MEAL PREFERENCES</p>
          <h2>Build your meal search.</h2>
          <p>
            Add only the details that matter today. You can leave any field
            empty.
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          <fieldset>
            <legend>Nutrition goals</legend>

            <div className="form-grid">
              <label>
                Maximum calories
                <input
                  type="number"
                  placeholder="Example: 650"
                  value={maxCalories}
                  onChange={(e) => setMaxCalories(e.target.value)}
                />
              </label>

              <label>
                Minimum protein (g)
                <input
                  type="number"
                  placeholder="Example: 30"
                  value={minProtein}
                  onChange={(e) => setMinProtein(e.target.value)}
                />
              </label>

              <label>
                Maximum carbs (g)
                <input
                  type="number"
                  placeholder="Example: 75"
                  value={maxCarbs}
                  onChange={(e) => setMaxCarbs(e.target.value)}
                />
              </label>

              <label>
                Maximum fat (g)
                <input
                  type="number"
                  placeholder="Example: 25"
                  value={maxFat}
                  onChange={(e) => setMaxFat(e.target.value)}
                />
              </label>

              <label>
                Maximum sugar (g)
                <input
                  type="number"
                  placeholder="Example: 20"
                  value={maxSugar}
                  onChange={(e) => setMaxSugar(e.target.value)}
                />
              </label>
            </div>
          </fieldset>

          <fieldset>
            <legend>Dining needs</legend>

            <div className="form-grid">
              <label>
                Dietary restriction
                <select
                  value={dietaryRestriction}
                  onChange={(e) => setDietaryRestriction(e.target.value)}
                >
                  <option value="">Select one</option>
                  <option>None</option>
                  <option>Vegetarian</option>
                  <option>Vegan</option>
                  <option>Halal</option>
                  <option>Gluten-free</option>
                </select>
              </label>

              <label>
                Allergies or ingredients to avoid
                <input
                  type="text"
                  placeholder="Example: peanuts, dairy"
                  value={allergies}
                  onChange={(e) => setAllergies(e.target.value)}
                />
              </label>

              <label>
                Meal period
                <select
                  value={mealPeriod}
                  onChange={(e) => setMealPeriod(e.target.value)}
                >
                  <option value="">Select one</option>
                  <option>Breakfast</option>
                  <option>Lunch</option>
                  <option>Dinner</option>
                  <option>Late night</option>
                </select>
              </label>

              <label>
                Which dining location are you closest to?
                <select
                  value={diningLocation}
                  onChange={(e) => setDiningLocation(e.target.value)}
                >
                  {diningLocations.map((loc) => (
                    <option key={loc} value={loc}>
                      {loc}
                    </option>
                  ))}
                </select>
              </label>
            </div>
          </fieldset>

          <fieldset>
            <legend>What should matter most?</legend>

            <div className="priority-options">
              <label>
                <input
                  type="radio"
                  name="priority"
                  checked={priority === "balanced"}
                  onChange={() => setPriority("balanced")}
                />
                Balanced nutrition and convenience
              </label>
              <label>
                <input
                  type="radio"
                  name="priority"
                  checked={priority === "nutrition"}
                  onChange={() => setPriority("nutrition")}
                />
                Better nutrition
              </label>
              <label>
                <input
                  type="radio"
                  name="priority"
                  checked={priority === "convenience"}
                  onChange={() => setPriority("convenience")}
                />
                Convenience
              </label>
            </div>
          </fieldset>

          <button
            className="primary-button"
            type="submit"
            disabled={submitting}
          >
            {submitting ? "Searching…" : "See meal options"}
          </button>

          {error && <p className="mock-note">{error}</p>}
        </form>
      </section>
      {showSidekick && (
        <aside className="sidekick-panel">
          <div className="sidekick-header">
            <div>
              <p className="eyebrow">AI SIDEKICK</p>
              <h2>HokieFuel</h2>
            </div>
            <button
              className="close-button"
              onClick={() => setShowSidekick(false)}
              aria-label="Close HokieFuel"
            >
              ×
            </button>
          </div>

          <p>
            Tell HokieFuel what you need. Soon it will help update your meal
            preferences using real dining data.
          </p>

          <div className="chat-placeholder">
            I care more about protein than walking distance.
          </div>

          <form
            className="chat-form"
            onSubmit={(event) => {
              event.preventDefault();
              if (chatMessage.trim()) {
                setChatSubmitted(true);
              }
            }}
          >
            <input
              aria-label="Message HokieFuel"
              placeholder="Ask HokieFuel about your meal..."
              value={chatMessage}
              onChange={(event) => setChatMessage(event.target.value)}
            />
            <button type="submit">Send</button>
          </form>

          {chatSubmitted && (
            <div className="sidekick-response">
              <strong>Prototype response</strong>
              <p>
                Your message will eventually be sent to HokieFuel, which will
                return structured preferences for the real dining-data search.
              </p>
            </div>
          )}
        </aside>
      )}
    </main>
  );
}
