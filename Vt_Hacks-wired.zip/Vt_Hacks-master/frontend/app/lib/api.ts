// Backend URL. Override at build time with a .env.local containing
// NEXT_PUBLIC_API_URL=... if you ever deploy the backend elsewhere.
export const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
