import os
from typing import Any

try:
    from databricks import sql
except ImportError:
    sql = None


# ============================================================
# CONFIG CHECK
# ============================================================

def _is_configured() -> bool:
    return bool(
        os.environ.get("DATABRICKS_HOST")
        and os.environ.get("DATABRICKS_HTTP_PATH")
        and os.environ.get("DATABRICKS_TOKEN")
    )


# ============================================================
# FEATURE LOOKUP
# ============================================================

def get_databricks_features(
    recipe_ids: list[str]
) -> dict[str, Any]:
    """
    Looks up precomputed nutrition/ranking features for the
    given recipe ids from a Databricks Delta table, via a
    SQL Warehouse connection.

    Returns an empty dict (safe no-op) if:
    - Databricks env vars aren't set yet, or
    - the databricks-sql-connector package isn't installed, or
    - the query fails for any reason (e.g. table doesn't exist yet)

    This means the rest of the app keeps working normally even
    before Databricks is wired up or if it's temporarily down.
    """

    if not recipe_ids or sql is None or not _is_configured():
        return {}

    table = os.environ.get(
        "DATABRICKS_TABLE",
        "main.vt_dining.food_features"
    )

    try:
        with sql.connect(
            server_hostname=os.environ["DATABRICKS_HOST"],
            http_path=os.environ["DATABRICKS_HTTP_PATH"],
            access_token=os.environ["DATABRICKS_TOKEN"],
        ) as conn:
            with conn.cursor() as cursor:
                placeholders = ",".join("?" for _ in recipe_ids)
                cursor.execute(
                    f"SELECT recipe_id, nutrition_score "
                    f"FROM {table} "
                    f"WHERE recipe_id IN ({placeholders})",
                    recipe_ids,
                )
                return {
                    str(row.recipe_id): row.nutrition_score
                    for row in cursor.fetchall()
                }
    except Exception as exc:
        print(
            f"[databricks_features] lookup failed, "
            f"continuing without it: {exc}"
        )
        return {}
