"""
Two Databricks-hosted agents that talk to each other to annotate each
recommended food with a personalized note.

  Agent 1 — NUTRITION ANALYST
      Scores each candidate food's nutrition profile on the numbers
      alone (health_score 1-10 + a one-line rationale). It has no idea
      what the student asked for.

  Agent 2 — STUDENT ADVISOR
      Reads the Analyst's scores plus the student's stated priority
      and writes the final one-sentence note shown to the student. If
      the Advisor thinks a score doesn't fit the student's priority
      (e.g. a high score for "nutrition" priority on a low-protein
      item), it does NOT silently override the Analyst — it flags that
      item with a concern.

  Interaction: any items the Advisor flags are sent BACK to the
  Analyst, together with the Advisor's concern, for one corrective
  pass. The Analyst re-scores just those items; the Advisor then
  writes its final notes using the revised scores. This is a real,
  bounded two-agent exchange — each call is a separate Databricks
  ai_query() invocation with its own persona and instructions, and
  each agent's prompt is built directly from the other agent's
  structured JSON reply. It is capped at one revision round, so a
  single request makes at most 4 model calls total (just 2 in the
  common case where the Advisor has no concerns).

This whole module is PURELY ADDITIVE. RecommendationService
(deterministic, in services/recommendation.py) remains the only thing
that filters or ranks food — these two agents only annotate items it
already picked. If Databricks is unreachable, not configured, or
either agent's reply doesn't parse, recommend() still returns the
base recommendations with a warning string instead of raising.
"""
import json
import os

from databricks import sql as databricks_sql

DATABRICKS_SERVER_HOSTNAME = os.getenv("DATABRICKS_SERVER_HOSTNAME")
DATABRICKS_HTTP_PATH = os.getenv("DATABRICKS_HTTP_PATH")
DATABRICKS_TOKEN = os.getenv("DATABRICKS_TOKEN")

# Pick whichever pay-per-token Foundation Model your workspace's
# "Serving" tab lists (region-dependent). This is a sane default seen
# in most workspaces, but check yours and override with the env var
# if it differs. Both agents share this endpoint — they're
# distinguished by persona/instructions, not by model.
DATABRICKS_MODEL_ENDPOINT = os.getenv(
    "DATABRICKS_MODEL_ENDPOINT", "databricks-meta-llama-3-3-70b-instruct"
)

MAX_ITEMS_TO_ANNOTATE = 5  # keep prompts small so the exchange stays fast

NUTRITION_ANALYST_PERSONA = (
    "You are the NUTRITION ANALYST agent in a two-agent system. Your only job is "
    "to score foods purely on their nutrition numbers. You do not know and do not "
    "consider the student's personal preference — that is the other agent's job. "
    "For each food, output a health_score from 1 (poor) to 10 (excellent: "
    "protein-dense relative to calories, reasonable fat/carbs) and a one-line "
    "rationale grounded only in the numbers given."
)

STUDENT_ADVISOR_PERSONA = (
    "You are the STUDENT ADVISOR agent in a two-agent system. You do not compute "
    "nutrition scores yourself — the NUTRITION ANALYST agent already did that, and "
    "its scores are given to you below. Your job is to turn those scores into one "
    "short, encouraging sentence (at most 12 words) per food, tailored to the "
    "student's stated priority. If an Analyst score looks inconsistent with the "
    "student's priority (for example, a high score on a 'nutrition' priority for a "
    "low-protein item), do NOT silently override it — set needs_recheck to true "
    "and give a short concern explaining what seems off, so the Analyst can review it."
)


def _configured() -> bool:
    return bool(
        DATABRICKS_SERVER_HOSTNAME and DATABRICKS_HTTP_PATH and DATABRICKS_TOKEN
    )


def _strip_code_fence(text: str) -> str:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        cleaned = cleaned.split("\n", 1)[-1] if "\n" in cleaned else cleaned
    return cleaned


def _run_agent(cursor, prompt: str, agent_label: str):
    """One ai_query() call = one agent turn. Logged so the exchange is
    visible in the backend terminal during a live demo."""
    print(f"[{agent_label}] -> Databricks: {prompt[:200]}...")
    cursor.execute(
        "SELECT ai_query(%(endpoint)s, %(prompt)s) AS ai_result",
        {"endpoint": DATABRICKS_MODEL_ENDPOINT, "prompt": prompt},
    )
    row = cursor.fetchone()
    raw = row[0] if row else None
    print(f"[{agent_label}] <- Databricks: {(raw or '')[:200]}...")
    if not raw:
        return None
    return json.loads(_strip_code_fence(raw))


def _analyst_prompt(payload, revision_note=None):
    prompt = f"{NUTRITION_ANALYST_PERSONA} Foods: {json.dumps(payload)}. "
    if revision_note:
        prompt += (
            "The STUDENT ADVISOR agent reviewed your previous scores and raised "
            f'this concern: "{revision_note}". Reconsider these specific items and '
            "respond again. "
        )
    prompt += (
        'Return ONLY a JSON array (no prose) of objects shaped '
        '{"id": "<id>", "health_score": <1-10>, "rationale": "<short>"}, '
        "one per food, same ids as given."
    )
    return prompt


def _advisor_prompt(payload, analyst_output, priority):
    return (
        f'{STUDENT_ADVISOR_PERSONA} Student priority: "{priority}". '
        f"NUTRITION ANALYST's scores: {json.dumps(analyst_output)}. "
        f"Original food data: {json.dumps(payload)}. "
        'Return ONLY a JSON array (no prose) of objects shaped '
        '{"id": "<id>", "note": "<sentence>", "needs_recheck": <true|false>, '
        '"concern": "<short reason, or empty string if none>"}, one per food, '
        "same ids as given."
    )


def enrich_recommendations(items, priority: str):
    """
    items: list of RecommendationItem (already built by
        RecommendationService.recommend()).
    priority: the request's priority string.

    Runs the two-agent exchange described above and appends one
    Databricks-generated sentence to match_explanation for at most the
    first MAX_ITEMS_TO_ANNOTATE items. Returns (items, warning_or_None).
    Never raises.
    """
    if not items:
        return items, None

    if not _configured():
        return items, None  # not configured yet — silent no-op, not an error

    subset = items[:MAX_ITEMS_TO_ANNOTATE]
    payload = [
        {
            "id": item.id,
            "food_name": item.food_name,
            "calories": item.nutrition.calories,
            "protein_g": item.nutrition.protein_g,
            "carbs_g": item.nutrition.carbs_g,
            "fat_g": item.nutrition.fat_g,
        }
        for item in subset
    ]

    try:
        with databricks_sql.connect(
            server_hostname=DATABRICKS_SERVER_HOSTNAME,
            http_path=DATABRICKS_HTTP_PATH,
            access_token=DATABRICKS_TOKEN,
        ) as connection:
            with connection.cursor() as cursor:
                # --- Turn 1: Nutrition Analyst scores every item ---
                analyst_output = _run_agent(
                    cursor, _analyst_prompt(payload), "NutritionAnalyst"
                )
                if analyst_output is None:
                    return items, "Databricks Nutrition Analyst returned no data."

                # --- Turn 2: Student Advisor reads Analyst's scores, writes notes ---
                advisor_output = _run_agent(
                    cursor,
                    _advisor_prompt(payload, analyst_output, priority),
                    "StudentAdvisor",
                )
                if advisor_output is None:
                    return items, "Databricks Student Advisor returned no data."

                # --- Interaction: Advisor's concerns go BACK to the Analyst ---
                flagged = [e for e in advisor_output if e.get("needs_recheck")]
                if flagged:
                    flagged_ids = {str(e["id"]) for e in flagged}
                    concern_text = "; ".join(
                        f"{e['id']}: {e.get('concern', '')}"
                        for e in flagged
                        if e.get("concern")
                    )
                    flagged_payload = [
                        food for food in payload if str(food["id"]) in flagged_ids
                    ]

                    revised = _run_agent(
                        cursor,
                        _analyst_prompt(flagged_payload, revision_note=concern_text),
                        "NutritionAnalyst (revision)",
                    )
                    if revised:
                        merged = {str(e["id"]): e for e in analyst_output}
                        merged.update({str(e["id"]): e for e in revised})
                        analyst_output = list(merged.values())

                        # --- Turn 3: Advisor finalizes using the revised scores ---
                        final_advisor_output = _run_agent(
                            cursor,
                            _advisor_prompt(payload, analyst_output, priority),
                            "StudentAdvisor (final)",
                        )
                        if final_advisor_output:
                            advisor_output = final_advisor_output

        notes = {
            str(entry["id"]): entry["note"]
            for entry in advisor_output
            if entry.get("note")
        }

    except Exception as exc:  # noqa: BLE001 - agents must never break /recommend
        return (
            items,
            f"Databricks agents unavailable ({exc.__class__.__name__}); "
            "showing base recommendations.",
        )

    for item in subset:
        note = notes.get(item.id)
        if note:
            item.match_explanation.append(f"Databricks insight: {note}")

    return items, None
